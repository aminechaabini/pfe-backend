package com.example.demo.project.domain.run;

public enum RunStatus {
    NOT_STARTED,
    IN_PROGRESS,
    COMPLETED,
    FAILED
}
