package com.example.demo.project.domain.test;

public interface Test {
}
