package com.example.demo.project.api;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.project.domain.test.TestSuite;
import com.example.demo.project.dto.suite.CreateTestSuiteRequest;
import com.example.demo.project.dto.suite.TestSuiteResponse;
import com.example.demo.project.dto.suite.UpdateTestSuiteRequest;
import com.example.demo.project.app.mapper.suite.SuiteMapper;
import com.example.demo.project.app.service.SuiteService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/suites")
public class SuiteController {
    private final SuiteService suiteService;

    public SuiteController(SuiteService suiteService) {
        this.suiteService = suiteService;
    }

    @PostMapping()
    public ResponseEntity<TestSuiteResponse> create(@RequestBody CreateTestSuiteRequest request) {
        return ResponseEntity.ok(SuiteMapper.toResponse(suiteService.create(request)));
    }

    @GetMapping("/{suiteId}")
    public ResponseEntity<TestSuiteResponse> findById(@PathVariable("suiteId") Long suiteId) {
        Optional<TestSuite> suite = suiteService.findById(suiteId);
        if (suite.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        return ResponseEntity.ok(SuiteMapper.toResponse(suite.get()));
    }

    @GetMapping()
    public ResponseEntity<List<TestSuiteResponse>> findAll() {
        List<TestSuite> suites = suiteService.findAll();
        List<TestSuiteResponse> responses = suites.stream()
                .map(SuiteMapper::toResponse)
                .toList();
        return ResponseEntity.ok(responses);
    }

    @PutMapping("/{suiteId}")
    public ResponseEntity<TestSuiteResponse> update(@PathVariable("suiteId") Long suiteId, @RequestBody UpdateTestSuiteRequest request) {
        return ResponseEntity.ok(SuiteMapper.toResponse(suiteService.update(suiteId, request)));
    }

    @DeleteMapping("/{suiteId}")
    public ResponseEntity<Void> delete(@PathVariable("suiteId") Long suiteId) {
        if (suiteService.delete(suiteId) == false) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        return ResponseEntity.ok(null);
    }

}
