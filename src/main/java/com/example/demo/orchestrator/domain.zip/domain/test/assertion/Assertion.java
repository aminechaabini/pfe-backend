package com.example.demo.orchestrator.domain.test.assertion;

public class Assertion {
    public AssertionType type;
    public String target;
    public String expected;
}
