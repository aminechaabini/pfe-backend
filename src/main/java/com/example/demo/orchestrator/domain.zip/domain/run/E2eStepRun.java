package com.example.demo.orchestrator.domain.run;

import com.example.demo.orchestrator.domain.test.e2e.E2eStep;

import java.util.List;

public class E2eStepRun {
    private E2eStep e2eStep;
    private List<AssertionResult> assertionResults;
}
