package com.example.demo.orchestrator.domain.run;

import java.util.List;

public class E2eTestRun extends TestCaseRun{
    private List<E2eStepRun> e2eStepRunList;
}
