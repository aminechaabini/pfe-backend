package com.example.demo.orchestrator.domain.test.request.body;

public interface Body {
}
