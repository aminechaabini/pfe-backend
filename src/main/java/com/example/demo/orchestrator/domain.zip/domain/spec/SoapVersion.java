package com.example.demo.orchestrator.domain.spec;

public enum SoapVersion {
    SOAP_1_1, SOAP_1_2
}
