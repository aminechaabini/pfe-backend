package com.example.demo.orchestrator.domain.run;

import com.example.demo.orchestrator.domain.test.api.ApiTest;

import java.util.List;

public class ApiTestRun extends TestCaseRun {
    List<AssertionResult> assertionResults;
}
