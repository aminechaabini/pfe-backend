package com.example.demo.orchestrator.domain.spec;

public enum EndpointType {
    REST, SOAP
}
