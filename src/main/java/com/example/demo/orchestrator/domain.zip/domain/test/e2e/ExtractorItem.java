package com.example.demo.orchestrator.domain.test.e2e;

public record ExtractorItem(String name, String path) {
}
