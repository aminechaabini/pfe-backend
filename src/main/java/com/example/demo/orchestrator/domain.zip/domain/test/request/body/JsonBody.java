package com.example.demo.orchestrator.domain.test.request.body;

import com.eclipsesource.json.JsonObject;

public class JsonBody implements Body{

    private JsonObject jsonObject;
}
