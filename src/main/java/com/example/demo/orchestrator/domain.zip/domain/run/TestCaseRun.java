package com.example.demo.orchestrator.domain.run;

import com.example.demo.orchestrator.domain.test.TestCase;

public abstract class TestCaseRun extends Run{
    private TestCase testCase;
}
