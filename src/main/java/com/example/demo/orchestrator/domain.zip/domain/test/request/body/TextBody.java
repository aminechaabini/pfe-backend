package com.example.demo.orchestrator.domain.test.request.body;

public class TextBody implements Body {
    private String text;
}
