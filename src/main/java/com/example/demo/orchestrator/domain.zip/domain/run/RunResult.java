package com.example.demo.orchestrator.domain.run;

public enum RunResult {
    SUCCESS,
    FAILURE
}
