package com.example.demo.project.domain.run;

public enum RunResult {
    SUCCESS,
    FAILURE
}
