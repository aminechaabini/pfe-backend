package com.example.demo.orchestrator.domain.test.request.body;

import nu.xom.Document;

public class XmlBody implements Body {
    private Document document;
}
