package com.example.demo.orchestrator.domain.test.request.body;

public class BinaryBody implements Body{
    private Byte[] bytes;
}
