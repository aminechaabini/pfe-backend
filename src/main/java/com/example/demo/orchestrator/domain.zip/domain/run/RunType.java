package com.example.demo.project.domain.run;

public enum RunType {
    SUITE,
    TEST
}
