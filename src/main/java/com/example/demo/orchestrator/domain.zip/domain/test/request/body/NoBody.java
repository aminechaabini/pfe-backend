package com.example.demo.orchestrator.domain.test.request.body;

public class NoBody implements Body{
}
