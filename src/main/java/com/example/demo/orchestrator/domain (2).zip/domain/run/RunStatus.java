package com.example.demo.orchestrator.domain.run;

public enum RunStatus {
    NOT_STARTED,
    IN_PROGRESS,
    COMPLETED,
    FAILED
}
