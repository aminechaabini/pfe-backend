package com.example.demo.orchestrator.domain.test;

public class SoapApiTest extends APITest{
}
