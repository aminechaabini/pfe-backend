package com.example.demo.orchestrator.domain.test;

public abstract class Runnable {

    private Long id;

    private String name; // unique within suite and can't be null or blank

    private String description;


}
