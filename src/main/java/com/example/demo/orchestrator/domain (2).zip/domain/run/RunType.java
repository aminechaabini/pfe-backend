package com.example.demo.orchestrator.domain.run;

public enum RunType {
    SUITE,
    TEST
}
