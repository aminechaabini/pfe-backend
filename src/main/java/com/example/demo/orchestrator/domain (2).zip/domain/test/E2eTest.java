package com.example.demo.orchestrator.domain.test;

public class E2eTest implements Runnable {

    // has multiple steps, each step we can validate output and fetch output to use in a future step,
    // each step is an api call
}
