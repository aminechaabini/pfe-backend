public abstract class APITest implements Test {
  private final String requestTemplate;    
  private final Map<String,String> data;   
}

