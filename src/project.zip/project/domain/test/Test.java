package project.domain;

public interface Test {
    private UUID id;
    private String name;
    private String script;

}
