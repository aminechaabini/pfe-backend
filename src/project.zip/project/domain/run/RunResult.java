public enum RunResult {
    SUCCESS,
    FAILURE
}
