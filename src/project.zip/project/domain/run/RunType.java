public enum RunType {
    SUITE,
    TEST
}
